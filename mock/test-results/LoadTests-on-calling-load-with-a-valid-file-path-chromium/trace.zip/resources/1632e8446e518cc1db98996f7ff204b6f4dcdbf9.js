import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ViewOutput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8e8a8cac"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/ViewOutput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import Table from "/node_modules/.vite/deps/react-bootstrap_Table.js?v=8e8a8cac";
export function ViewOutput(prop, responseMap) {
  let concatenatedResponse;
  let convertedResponseMap = responseMap;
  if (responseMap == null || convertedResponseMap.type == "error") {
    concatenatedResponse = /* @__PURE__ */ jsxDEV("div", { children: "No dataset has been loaded at this time." }, void 0, false, {
      fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/ViewOutput.tsx",
      lineNumber: 24,
      columnNumber: 28
    }, this);
  } else {
    let columns = [];
    console.log(convertedResponseMap);
    for (let i = 0; i < convertedResponseMap.data.headers.length; i++) {
      columns.push(/* @__PURE__ */ jsxDEV("th", { children: convertedResponseMap.data.headers[i] }, void 0, false, {
        fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/ViewOutput.tsx",
        lineNumber: 32,
        columnNumber: 20
      }, this));
    }
    let headers = /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { children: columns }, void 0, false, {
      fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/ViewOutput.tsx",
      lineNumber: 34,
      columnNumber: 39
    }, this) }, void 0, false, {
      fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/ViewOutput.tsx",
      lineNumber: 34,
      columnNumber: 32
    }, this);
    let rows = [];
    for (let i = 0; i < convertedResponseMap.data.body.length; i++) {
      let row = [];
      for (let j = 0; j < convertedResponseMap.data.body[0].length; j++) {
        row.push(/* @__PURE__ */ jsxDEV("td", { children: convertedResponseMap.data.body[i][j] }, void 0, false, {
          fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/ViewOutput.tsx",
          lineNumber: 41,
          columnNumber: 18
        }, this));
      }
      rows.push(/* @__PURE__ */ jsxDEV("tr", { children: row }, void 0, false, {
        fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/ViewOutput.tsx",
        lineNumber: 43,
        columnNumber: 17
      }, this));
    }
    let data = /* @__PURE__ */ jsxDEV("tbody", { children: rows }, void 0, false, {
      fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/ViewOutput.tsx",
      lineNumber: 45,
      columnNumber: 29
    }, this);
    let table = /* @__PURE__ */ jsxDEV(Table, { striped: true, bordered: true, hover: true, children: [
      headers,
      data
    ] }, void 0, true, {
      fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/ViewOutput.tsx",
      lineNumber: 46,
      columnNumber: 30
    }, this);
    concatenatedResponse = /* @__PURE__ */ jsxDEV("div", { "aria-label": "view-response", children: table }, void 0, false, {
      fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/ViewOutput.tsx",
      lineNumber: 50,
      columnNumber: 28
    }, this);
  }
  prop.setResponses([...prop.responses, concatenatedResponse, /* @__PURE__ */ jsxDEV("hr", { "aria-label": "command-separator" }, void 0, false, {
    fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/ViewOutput.tsx",
    lineNumber: 52,
    columnNumber: 63
  }, this)]);
}
_c = ViewOutput;
var _c;
$RefreshReg$(_c, "ViewOutput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/ViewOutput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkIrQjtBQTdCL0IsMkJBQW1CQTtBQUFzQixNQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDaEQsT0FBT0MsV0FBVztBQXFCWCxnQkFBU0MsV0FBV0MsTUFBdUJDLGFBQTBCO0FBRXhFLE1BQUlDO0FBQ0osTUFBSUMsdUJBQXVDRjtBQUczQyxNQUFJQSxlQUFlLFFBQVFFLHFCQUFxQkMsUUFBUSxTQUFTO0FBQzdERiwyQkFBdUIsdUJBQUMsU0FBSSx3REFBTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZDO0FBQUEsRUFDeEUsT0FHSztBQUNELFFBQUlHLFVBQTBCO0FBQzlCQyxZQUFRQyxJQUFJSixvQkFBb0I7QUFFaEMsYUFBU0ssSUFBSSxHQUFHQSxJQUFJTCxxQkFBcUJNLEtBQUtDLFFBQVFDLFFBQVFILEtBQU07QUFDaEVILGNBQVFPLEtBQUssdUJBQUMsUUFBSVQsK0JBQXFCTSxLQUFLQyxRQUFRRixDQUFDLEtBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEMsQ0FBSztBQUFBLElBQ2hFO0FBQ0EsUUFBSUUsVUFBd0IsdUJBQUMsV0FBTSxpQ0FBQyxRQUFJTCxxQkFBTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWEsS0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5QjtBQUdyRCxRQUFJUSxPQUFzQjtBQUMxQixhQUFTTCxJQUFJLEdBQUdBLElBQUlMLHFCQUFxQk0sS0FBS0ssS0FBS0gsUUFBT0gsS0FBTTtBQUM1RCxVQUFJTyxNQUFzQjtBQUMxQixlQUFTQyxJQUFJLEdBQUdBLElBQUliLHFCQUFxQk0sS0FBS0ssS0FBSyxDQUFDLEVBQUVILFFBQVFLLEtBQU07QUFDaEVELFlBQUlILEtBQUssdUJBQUMsUUFBSVQsK0JBQXFCTSxLQUFLSyxLQUFLTixDQUFDLEVBQUVRLENBQUMsS0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQyxDQUFLO0FBQUEsTUFDNUQ7QUFDQUgsV0FBS0QsS0FBSyx1QkFBQyxRQUFJRyxpQkFBTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVMsQ0FBSztBQUFBLElBQzVCO0FBQ0EsUUFBSU4sT0FBcUIsdUJBQUMsV0FBT0ksa0JBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFhO0FBQ3RDLFFBQUlJLFFBQ0EsdUJBQUMsU0FBTSxTQUFPLE1BQUMsVUFBUSxNQUFDLE9BQUssTUFDeEJQO0FBQUFBO0FBQUFBLE1BQ0FEO0FBQUFBLFNBRkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBR0pQLDJCQUF3Qix1QkFBQyxTQUFJLGNBQWEsaUJBQWlCZSxtQkFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5QztBQUFBLEVBQ3JFO0FBRUFqQixPQUFLa0IsYUFBYSxDQUFDLEdBQUdsQixLQUFLbUIsV0FBV2pCLHNCQUN0Qyx1QkFBQyxRQUFHLGNBQWEsdUJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBcUMsQ0FBSyxDQUFDO0FBQy9DO0FBQUNrQixLQTFDZXJCO0FBQVUsSUFBQXFCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJTZXRTdGF0ZUFjdGlvbiIsIlRhYmxlIiwiVmlld091dHB1dCIsInByb3AiLCJyZXNwb25zZU1hcCIsImNvbmNhdGVuYXRlZFJlc3BvbnNlIiwiY29udmVydGVkUmVzcG9uc2VNYXAiLCJ0eXBlIiwiY29sdW1ucyIsImNvbnNvbGUiLCJsb2ciLCJpIiwiZGF0YSIsImhlYWRlcnMiLCJsZW5ndGgiLCJwdXNoIiwicm93cyIsImJvZHkiLCJyb3ciLCJqIiwidGFibGUiLCJzZXRSZXNwb25zZXMiLCJyZXNwb25zZXMiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlZpZXdPdXRwdXQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IERpc3BhdGNoLCBTZXRTdGF0ZUFjdGlvbiB9IGZyb20gXCJyZWFjdFwiXG5pbXBvcnQgVGFibGUgZnJvbSAncmVhY3QtYm9vdHN0cmFwL1RhYmxlJztcblxuaW50ZXJmYWNlIFJFUExPdXRwdXRQcm9wc3tcbiAgICAvLyBUT0RPOiBGaWxsIHRoaXMgd2l0aCBkZXNpcmVkIHByb3BzLi4uIE1heWJlIHNvbWV0aGluZyB0byBrZWVwIHRyYWNrIG9mIHRoZSBzdWJtaXR0ZWQgY29tbWFuZHNcbiAgICB0b2dnbGU6IG51bWJlclxuICAgIHJlc3BvbnNlczogSlNYLkVsZW1lbnRbXVxuICAgIHNldFJlc3BvbnNlczogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248SlNYLkVsZW1lbnRbXT4+XG4gIH1cblxuaW50ZXJmYWNlIFZpZXdPdXRwdXRQcm9wIHtcbiAgICB0eXBlOiBzdHJpbmdcbiAgICBkYXRhOiBkYXRhUmVzcG9uc2VcbiAgICBlcnJvcl9tZXNzYWdlOiBzdHJpbmdcbn1cblxuaW50ZXJmYWNlIGRhdGFSZXNwb25zZSB7XG4gICAgaGVhZGVyczogc3RyaW5nW11cbiAgICBib2R5OiBzdHJpbmdbXVtdXG59XG5cblxuZXhwb3J0IGZ1bmN0aW9uIFZpZXdPdXRwdXQocHJvcDogUkVQTE91dHB1dFByb3BzLCByZXNwb25zZU1hcDogSlNPTiB8IG51bGwpIHtcbiAgIFxuICAgIGxldCBjb25jYXRlbmF0ZWRSZXNwb25zZSA6SlNYLkVsZW1lbnQ7XG4gICAgbGV0IGNvbnZlcnRlZFJlc3BvbnNlTWFwOiBWaWV3T3V0cHV0UHJvcCA9IHJlc3BvbnNlTWFwIGFzIHVua25vd24gYXMgVmlld091dHB1dFByb3A7XG4gICAgXG4gICAgLy8gZXJyb3JlZCByZXNwb25zZSBtYXBzIHNob3VsZCBvdXRwdXQgbm90aGluZyBidXQgYW4gaW5mb3JtYXRpdmUgbWVzc2FnZS5cbiAgICBpZiAocmVzcG9uc2VNYXAgPT0gbnVsbCB8fCBjb252ZXJ0ZWRSZXNwb25zZU1hcC50eXBlID09IFwiZXJyb3JcIikge1xuICAgICAgICBjb25jYXRlbmF0ZWRSZXNwb25zZSA9IDxkaXY+Tm8gZGF0YXNldCBoYXMgYmVlbiBsb2FkZWQgYXQgdGhpcyB0aW1lLjwvZGl2PlxuICAgIH0gXG5cbiAgICAvLyBjcmVhdGluZyB0aGUgdGFibGVcbiAgICBlbHNlIHtcbiAgICAgICAgbGV0IGNvbHVtbnMgOiBKU1guRWxlbWVudFtdID0gW11cbiAgICAgICAgY29uc29sZS5sb2coY29udmVydGVkUmVzcG9uc2VNYXApXG5cbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjb252ZXJ0ZWRSZXNwb25zZU1hcC5kYXRhLmhlYWRlcnMubGVuZ3RoOyBpICsrKSB7XG4gICAgICAgICAgICBjb2x1bW5zLnB1c2goPHRoPntjb252ZXJ0ZWRSZXNwb25zZU1hcC5kYXRhLmhlYWRlcnNbaV19PC90aD4pXG4gICAgICAgIH1cbiAgICAgICAgbGV0IGhlYWRlcnMgOiBKU1guRWxlbWVudCA9IDx0aGVhZD48dHI+e2NvbHVtbnN9PC90cj48L3RoZWFkPlxuXG4gICAgICAgIC8vIHBvcG91bGF0aW5nIHRoZSByZXN0IG9mIHRoZSBkYXRhXG4gICAgICAgIGxldCByb3dzIDpKU1guRWxlbWVudFtdID0gW11cbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjb252ZXJ0ZWRSZXNwb25zZU1hcC5kYXRhLmJvZHkubGVuZ3RoO2kgKyspIHtcbiAgICAgICAgICAgIGxldCByb3cgOiBKU1guRWxlbWVudFtdID0gW107XG4gICAgICAgICAgICBmb3IgKGxldCBqID0gMDsgaiA8IGNvbnZlcnRlZFJlc3BvbnNlTWFwLmRhdGEuYm9keVswXS5sZW5ndGg7IGogKyspIHtcbiAgICAgICAgICAgICAgICByb3cucHVzaCg8dGQ+e2NvbnZlcnRlZFJlc3BvbnNlTWFwLmRhdGEuYm9keVtpXVtqXX08L3RkPilcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJvd3MucHVzaCg8dHI+e3Jvd308L3RyPilcbiAgICAgICAgfVxuICAgICAgICBsZXQgZGF0YSA6IEpTWC5FbGVtZW50ID0gPHRib2R5Pntyb3dzfTwvdGJvZHk+XG4gICAgICAgIGxldCB0YWJsZTogSlNYLkVsZW1lbnQgPSBcbiAgICAgICAgICAgIDxUYWJsZSBzdHJpcGVkIGJvcmRlcmVkIGhvdmVyPlxuICAgICAgICAgICAgICAgIHtoZWFkZXJzfVxuICAgICAgICAgICAgICAgIHtkYXRhfVxuICAgICAgICAgICAgPC9UYWJsZT5cbiAgICAgICAgXG5cbiAgICAgICAgY29uY2F0ZW5hdGVkUmVzcG9uc2UgPSAgPGRpdiBhcmlhLWxhYmVsID0gJ3ZpZXctcmVzcG9uc2UnPnt0YWJsZX08L2Rpdj4gICAgIFxuICAgIH1cblxuICAgIHByb3Auc2V0UmVzcG9uc2VzKFsuLi5wcm9wLnJlc3BvbnNlcywgY29uY2F0ZW5hdGVkUmVzcG9uc2UsIFxuICAgIDxociBhcmlhLWxhYmVsID0gXCJjb21tYW5kLXNlcGFyYXRvclwiPjwvaHI+XSlcbn0iXSwiZmlsZSI6Ii9Vc2Vycy9zZWFuL0RvY3VtZW50cy9jczMyL21vY2stbXN1bjU5LXN5dTY2L21vY2svc3JjL2NvbXBvbmVudHMvVmlld091dHB1dC50c3gifQ==