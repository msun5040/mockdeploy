import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8e8a8cac"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/REPLInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/src/styles/main.css?t=1697122193990";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=8e8a8cac"; const useState = __vite__cjsImport4_react["useState"];
import { ControlledInput } from "/src/components/ControlledInput.tsx";
import { LoadOutput } from "/src/components/LoadOutput.tsx?t=1697124096157";
import { ViewOutput } from "/src/components/ViewOutput.tsx?t=1697122507780";
import { loadResponse } from "/src/components/response.tsx";
import Button from "/node_modules/.vite/deps/react-bootstrap_Button.js?v=8e8a8cac";
export function REPLInput(props) {
  _s();
  const [commandString, setCommandString] = useState("");
  const [count, setCount] = useState(0);
  const [dataMap, setDataMap] = useState(/* @__PURE__ */ new Map());
  function handle(command) {
    if (command == "") {
      props.setResponses([...props.responses, /* @__PURE__ */ jsxDEV("hr", { "aria-label": "command-separator" }, void 0, false, {
        fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/REPLInput.tsx",
        lineNumber: 43,
        columnNumber: 47
      }, this)]);
    }
    let splitCommand = command.split(" ");
    let parsedCommand = splitCommand[0];
    let response;
    if (splitCommand[0].toLowerCase() == "load_csv") {
      if (splitCommand.length < 2) {
        props.setResponses([...props.responses, /* @__PURE__ */ jsxDEV("div", { className: "error-message", "aria-label": "load-error", children: /* @__PURE__ */ jsxDEV("p", { children: /* @__PURE__ */ jsxDEV("b", { children: "load_csv requires at least 1 argument." }, void 0, false, {
          fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/REPLInput.tsx",
          lineNumber: 53,
          columnNumber: 18
        }, this) }, void 0, false, {
          fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/REPLInput.tsx",
          lineNumber: 53,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/REPLInput.tsx",
          lineNumber: 52,
          columnNumber: 49
        }, this), /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
          fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/REPLInput.tsx",
          lineNumber: 54,
          columnNumber: 21
        }, this)]);
      } else {
        if (dataMap.has(splitCommand[1])) {
          response = dataMap.get(splitCommand[1]);
        } else {
          response = loadResponse(splitCommand);
          setDataMap(dataMap.set(splitCommand[1], response));
        }
      }
      console.log(response);
      props.setCurrentDataset(response);
      LoadOutput(command, props, response);
    } else if (splitCommand[0].toLowerCase() == "mode") {
      if (props.verbosity == 0) {
        props.setVerbosity(1);
      } else {
        props.setVerbosity(0);
      }
    } else if (splitCommand[0].toLowerCase() == "view") {
      response = loadResponse(splitCommand);
      ViewOutput(props, props.currentDataset);
      handleSubmit(parsedCommand);
    } else if (splitCommand[0].toLowerCase() == "search") {
      response = loadResponse(splitCommand);
      handleSubmit(parsedCommand);
    } else {
      response = loadResponse(splitCommand);
      handleSubmit(command + " is not a valid command.");
    }
  }
  function handleSubmit(commandString2) {
    setCount(count + 1);
    props.setHistory([...props.history, commandString2]);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-input", children: [
    /* @__PURE__ */ jsxDEV("fieldset", { children: [
      /* @__PURE__ */ jsxDEV("legend", { children: "Enter a command:" }, void 0, false, {
        fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/REPLInput.tsx",
        lineNumber: 104,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV(ControlledInput, { value: commandString, setValue: setCommandString, ariaLabel: "Command input" }, void 0, false, {
        fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/REPLInput.tsx",
        lineNumber: 105,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/REPLInput.tsx",
      lineNumber: 103,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(Button, { variant: "primary", "aria-label": "submit-button", onClick: () => handle(commandString), children: [
      "Submitted ",
      count,
      " "
    ] }, void 0, true, {
      fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/REPLInput.tsx",
      lineNumber: 108,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/REPLInput.tsx",
    lineNumber: 98,
    columnNumber: 10
  }, this);
}
_s(REPLInput, "apUi2ITpjdgJ92H6+OSrZF9ylYo=");
_c = REPLInput;
var _c;
$RefreshReg$(_c, "REPLInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/REPLInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0RnRDs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFsRGhELE9BQU87QUFDUCxTQUFtQ0EsZ0JBQWU7QUFDbEQsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVFDLGtCQUFpQjtBQUN6QixTQUFTQyxrQkFBa0I7QUFFM0IsU0FBUUMsb0JBQW1CO0FBQzNCLE9BQU9DLFlBQVk7QUF3QlosZ0JBQVNDLFVBQVVDLE9BQXdCO0FBQUFDLEtBQUE7QUFHOUMsUUFBTSxDQUFDQyxlQUFlQyxnQkFBZ0IsSUFBSVYsU0FBaUIsRUFBRTtBQUU3RCxRQUFNLENBQUNXLE9BQU9DLFFBQVEsSUFBSVosU0FBaUIsQ0FBQztBQUc1QyxRQUFNLENBQUNhLFNBQVNDLFVBQVUsSUFBR2QsU0FBUyxvQkFBSWUsSUFBa0IsQ0FBQztBQVE3RCxXQUFTQyxPQUFPQyxTQUFrQjtBQUVoQyxRQUFJQSxXQUFXLElBQUk7QUFDakJWLFlBQU1XLGFBQWEsQ0FBQyxHQUFHWCxNQUFNWSxXQUFXLHVCQUFDLFFBQUcsY0FBYSx1QkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxQyxDQUFLLENBQUM7QUFBQSxJQUNyRjtBQUVBLFFBQUlDLGVBQTBCSCxRQUFRSSxNQUFNLEdBQUc7QUFDL0MsUUFBSUMsZ0JBQXlCRixhQUFhLENBQUM7QUFFM0MsUUFBSUc7QUFDSixRQUFJSCxhQUFhLENBQUMsRUFBRUksWUFBWSxLQUFLLFlBQVk7QUFFL0MsVUFBSUosYUFBYUssU0FBUyxHQUFHO0FBRTNCbEIsY0FBTVcsYUFBYSxDQUFDLEdBQUdYLE1BQU1ZLFdBQzNCLHVCQUFDLFNBQUksV0FBYSxpQkFBaUIsY0FBYSxjQUM5QyxpQ0FBQyxPQUFFLGlDQUFDLE9BQUUsc0RBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QyxLQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdELEtBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxHQUNGLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFJLENBQUssQ0FBQztBQUFBLE1BRVosT0FBTztBQUVMLFlBQUlOLFFBQVFhLElBQUlOLGFBQWEsQ0FBQyxDQUFDLEdBQUU7QUFDL0JHLHFCQUFXVixRQUFRYyxJQUFJUCxhQUFhLENBQUMsQ0FBQztBQUFBLFFBRXhDLE9BQU87QUFFTEcscUJBQVduQixhQUFhZ0IsWUFBWTtBQUNwQ04scUJBQVdELFFBQVFlLElBQUlSLGFBQWEsQ0FBQyxHQUFHRyxRQUFRLENBQUM7QUFBQSxRQUNuRDtBQUFBLE1BRUY7QUFJQU0sY0FBUUMsSUFBSVAsUUFBUTtBQUNwQmhCLFlBQU13QixrQkFBa0JSLFFBQVE7QUFDaENyQixpQkFBV2UsU0FBVVYsT0FBT2dCLFFBQVE7QUFBQSxJQUd0QyxXQUFXSCxhQUFhLENBQUMsRUFBRUksWUFBWSxLQUFLLFFBQVE7QUFDbEQsVUFBSWpCLE1BQU15QixhQUFhLEdBQUc7QUFDeEJ6QixjQUFNMEIsYUFBYSxDQUFDO0FBQUEsTUFDdEIsT0FBTztBQUNMMUIsY0FBTTBCLGFBQWEsQ0FBQztBQUFBLE1BQ3RCO0FBQUEsSUFFRixXQUFXYixhQUFhLENBQUMsRUFBRUksWUFBWSxLQUFLLFFBQVE7QUFDbERELGlCQUFXbkIsYUFBYWdCLFlBQVk7QUFDcENqQixpQkFBV0ksT0FBT0EsTUFBTTJCLGNBQWM7QUFHdENDLG1CQUFhYixhQUFhO0FBQUEsSUFFNUIsV0FBV0YsYUFBYSxDQUFDLEVBQUVJLFlBQVksS0FBSyxVQUFVO0FBQ3BERCxpQkFBV25CLGFBQWFnQixZQUFZO0FBQ3BDZSxtQkFBYWIsYUFBYTtBQUFBLElBQzVCLE9BQU87QUFDTEMsaUJBQVduQixhQUFhZ0IsWUFBWTtBQUNwQ2UsbUJBQWFsQixVQUFVLDBCQUEwQjtBQUFBLElBQ25EO0FBQUEsRUFFRjtBQUVBLFdBQVNrQixhQUFhMUIsZ0JBQXdCO0FBQzVDRyxhQUFTRCxRQUFRLENBQUM7QUFDbEJKLFVBQU02QixXQUFXLENBQUMsR0FBRzdCLE1BQU04QixTQUFTNUIsY0FBYSxDQUFDO0FBQUEsRUFDcEQ7QUFPQSxTQUNJLHVCQUFDLFNBQUksV0FBVSxjQUtYO0FBQUEsMkJBQUMsY0FDQztBQUFBLDZCQUFDLFlBQU8sZ0NBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3QjtBQUFBLE1BQ3hCLHVCQUFDLG1CQUFnQixPQUFPQSxlQUFlLFVBQVVDLGtCQUFrQixXQUFXLG1CQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThGO0FBQUEsU0FGaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFFQSx1QkFBQyxVQUFPLFNBQVUsV0FBVSxjQUFXLGlCQUFnQixTQUFXLE1BQU1NLE9BQU9QLGFBQWEsR0FBRztBQUFBO0FBQUEsTUFBV0U7QUFBQUEsTUFBTTtBQUFBLFNBQWhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUg7QUFBQSxPQVZySDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBV0E7QUFFTjtBQUFDSCxHQXhHYUYsV0FBUztBQUFBZ0MsS0FBVGhDO0FBQVMsSUFBQWdDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkNvbnRyb2xsZWRJbnB1dCIsIkxvYWRPdXRwdXQiLCJWaWV3T3V0cHV0IiwibG9hZFJlc3BvbnNlIiwiQnV0dG9uIiwiUkVQTElucHV0IiwicHJvcHMiLCJfcyIsImNvbW1hbmRTdHJpbmciLCJzZXRDb21tYW5kU3RyaW5nIiwiY291bnQiLCJzZXRDb3VudCIsImRhdGFNYXAiLCJzZXREYXRhTWFwIiwiTWFwIiwiaGFuZGxlIiwiY29tbWFuZCIsInNldFJlc3BvbnNlcyIsInJlc3BvbnNlcyIsInNwbGl0Q29tbWFuZCIsInNwbGl0IiwicGFyc2VkQ29tbWFuZCIsInJlc3BvbnNlIiwidG9Mb3dlckNhc2UiLCJsZW5ndGgiLCJoYXMiLCJnZXQiLCJzZXQiLCJjb25zb2xlIiwibG9nIiwic2V0Q3VycmVudERhdGFzZXQiLCJ2ZXJib3NpdHkiLCJzZXRWZXJib3NpdHkiLCJjdXJyZW50RGF0YXNldCIsImhhbmRsZVN1Ym1pdCIsInNldEhpc3RvcnkiLCJoaXN0b3J5IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSRVBMSW5wdXQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAnLi4vc3R5bGVzL21haW4uY3NzJztcbmltcG9ydCB7IERpc3BhdGNoLCBTZXRTdGF0ZUFjdGlvbiwgdXNlU3RhdGV9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IENvbnRyb2xsZWRJbnB1dCB9IGZyb20gJy4vQ29udHJvbGxlZElucHV0JztcbmltcG9ydCB7TG9hZE91dHB1dH0gZnJvbSAnLi9Mb2FkT3V0cHV0J1xuaW1wb3J0IHsgVmlld091dHB1dCB9IGZyb20gJy4vVmlld091dHB1dCc7XG5cbmltcG9ydCB7bG9hZFJlc3BvbnNlfSBmcm9tICcuL3Jlc3BvbnNlJ1xuaW1wb3J0IEJ1dHRvbiBmcm9tICdyZWFjdC1ib290c3RyYXAvQnV0dG9uJztcblxuaW50ZXJmYWNlIFJFUExJbnB1dFByb3Bze1xuICAvLyBUT0RPOiBGaWxsIHRoaXMgd2l0aCBkZXNpcmVkIHByb3BzLi4uIE1heWJlIHNvbWV0aGluZyB0byBrZWVwIHRyYWNrIG9mIHRoZSBzdWJtaXR0ZWQgY29tbWFuZHNcbiAgaGlzdG9yeTogc3RyaW5nW11cbiAgc2V0SGlzdG9yeTogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248c3RyaW5nW10+PlxuXG4gIHRvZ2dsZTogbnVtYmVyXG4gIHNldFRvZ2dsZTogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248bnVtYmVyPj5cblxuICByZXNwb25zZXM6IEpTWC5FbGVtZW50W11cbiAgc2V0UmVzcG9uc2VzOiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxKU1guRWxlbWVudFtdPj5cblxuICBkYXRhTWFwOiBNYXA8c3RyaW5nLCBKU09OPlxuICBzZXREYXRhTWFwOiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxNYXA8c3RyaW5nLCBKU09OPj4+XG5cbiAgY3VycmVudERhdGFzZXQ6IEpTT04gfCBudWxsXG4gIHNldEN1cnJlbnREYXRhc2V0OiAgRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248SlNPTiB8IG51bGw+PlxuXG4gIHZlcmJvc2l0eTogbnVtYmVyXG4gIHNldFZlcmJvc2l0eTogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248bnVtYmVyPj5cbn1cbi8vIFlvdSBjYW4gdXNlIGEgY3VzdG9tIGludGVyZmFjZSBvciBleHBsaWNpdCBmaWVsZHMgb3IgYm90aCEgQW4gYWx0ZXJuYXRpdmUgdG8gdGhlIGN1cnJlbnQgZnVuY3Rpb24gaGVhZGVyIG1pZ2h0IGJlOlxuLy8gUkVQTElucHV0KGhpc3Rvcnk6IHN0cmluZ1tdLCBzZXRIaXN0b3J5OiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxzdHJpbmdbXT4+KVxuZXhwb3J0IGZ1bmN0aW9uIFJFUExJbnB1dChwcm9wcyA6IFJFUExJbnB1dFByb3BzKSB7XG4gICAgLy8gUmVtZW1iZXI6IGxldCBSZWFjdCBtYW5hZ2Ugc3RhdGUgaW4geW91ciB3ZWJhcHAuIFxuICAgIC8vIE1hbmFnZXMgdGhlIGNvbnRlbnRzIG9mIHRoZSBpbnB1dCBib3hcbiAgICBjb25zdCBbY29tbWFuZFN0cmluZywgc2V0Q29tbWFuZFN0cmluZ10gPSB1c2VTdGF0ZTxzdHJpbmc+KCcnKTtcbiAgICAvLyBUT0RPIFdJVEggVEEgOiBhZGQgYSBjb3VudCBzdGF0ZVxuICAgIGNvbnN0IFtjb3VudCwgc2V0Q291bnRdID0gdXNlU3RhdGU8bnVtYmVyPigwKTtcbiAgICAvLyBUT0RPIFdJVEggVEE6IGJ1aWxkIGEgaGFuZGxlU3VibWl0IGZ1bmN0aW9uIGNhbGxlZCBpbiBidXR0b24gb25DbGlja1xuICAgIC8vY29uc3QgW2RhdGFNYXAsIHNldERhdGFNYXBdID0gdXNlU3RhdGU8eyBba2V5OiBzdHJpbmddOiBKU09OIH0+KHt9KTtcbiAgICBjb25zdCBbZGF0YU1hcCwgc2V0RGF0YU1hcF0gPXVzZVN0YXRlKG5ldyBNYXA8c3RyaW5nLCBKU09OPigpKVxuXG5cbiAgICBcbiAgICAvKipcbiAgICAgKiBoYW5kbGVzIHRoZSBjb21tYW5kLWxpbmUgaW5wdXQgYW5kIG91dHB1dHMgdGhlIGFwcHJvcmlhdGUgcmVzcG9uc2VcbiAgICAgKiBAcGFyYW0gY29tbWFuZCB0aGUgZW5kcG9pbnQgdG8gYmUgaGl0XG4gICAgICovXG4gICAgZnVuY3Rpb24gaGFuZGxlKGNvbW1hbmQgOiBzdHJpbmcpIHtcbiAgICAgIFxuICAgICAgaWYgKGNvbW1hbmQgPT0gXCJcIikge1xuICAgICAgICBwcm9wcy5zZXRSZXNwb25zZXMoWy4uLnByb3BzLnJlc3BvbnNlcywgPGhyIGFyaWEtbGFiZWwgPSBcImNvbW1hbmQtc2VwYXJhdG9yXCI+PC9ocj5dKTtcbiAgICAgIH1cblxuICAgICAgbGV0IHNwbGl0Q29tbWFuZCA6IHN0cmluZ1tdID0gY29tbWFuZC5zcGxpdChcIiBcIilcbiAgICAgIGxldCBwYXJzZWRDb21tYW5kIDogc3RyaW5nID0gc3BsaXRDb21tYW5kWzBdO1xuICAgICAgLy8gY29uc29sZS5sb2coc3BsaXRDb21tYW5kWzBdLnRvTG93ZXJDYXNlKCkpXG4gICAgICBsZXQgcmVzcG9uc2U6IGFueTtcbiAgICAgIGlmIChzcGxpdENvbW1hbmRbMF0udG9Mb3dlckNhc2UoKSA9PSBcImxvYWRfY3N2XCIpIHtcbiAgICAgICAgLy8gZGlzcGxheSBlcnJvciBtZXNzYWdlIGZvciB1c2VyXG4gICAgICAgIGlmIChzcGxpdENvbW1hbmQubGVuZ3RoIDwgMikge1xuXG4gICAgICAgICAgcHJvcHMuc2V0UmVzcG9uc2VzKFsuLi5wcm9wcy5yZXNwb25zZXMsIFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWUgPSB7J2Vycm9yLW1lc3NhZ2UnfSBhcmlhLWxhYmVsPSB7J2xvYWQtZXJyb3InfT5cbiAgICAgICAgICAgICAgPHA+PGI+bG9hZF9jc3YgcmVxdWlyZXMgYXQgbGVhc3QgMSBhcmd1bWVudC48L2I+PC9wPlxuICAgICAgICAgICAgPC9kaXY+LCBcbiAgICAgICAgICA8aHI+PC9ocj5dKVxuXG4gICAgICAgIH0gZWxzZSB7XG5cbiAgICAgICAgICBpZiAoZGF0YU1hcC5oYXMoc3BsaXRDb21tYW5kWzFdKSl7XG4gICAgICAgICAgICByZXNwb25zZSA9IGRhdGFNYXAuZ2V0KHNwbGl0Q29tbWFuZFsxXSlcblxuICAgICAgICAgIH0gZWxzZSB7XG5cbiAgICAgICAgICAgIHJlc3BvbnNlID0gbG9hZFJlc3BvbnNlKHNwbGl0Q29tbWFuZClcbiAgICAgICAgICAgIHNldERhdGFNYXAoZGF0YU1hcC5zZXQoc3BsaXRDb21tYW5kWzFdLCByZXNwb25zZSkpXG4gICAgICAgICAgfVxuXG4gICAgICAgIH1cblxuXG4gICAgICAgIC8vIHNldHRpbmcgdGhlIGN1cnJlbnQgZGF0YXNldCBmb3Igb3RoZXIgaGFuZGxlcnMgdG8gdXNlXG4gICAgICAgIGNvbnNvbGUubG9nKHJlc3BvbnNlKVxuICAgICAgICBwcm9wcy5zZXRDdXJyZW50RGF0YXNldChyZXNwb25zZSlcbiAgICAgICAgTG9hZE91dHB1dChjb21tYW5kICwgcHJvcHMsIHJlc3BvbnNlKVxuICAgICAgICBcblxuICAgICAgfSBlbHNlIGlmIChzcGxpdENvbW1hbmRbMF0udG9Mb3dlckNhc2UoKSA9PSBcIm1vZGVcIikge1xuICAgICAgICBpZiAocHJvcHMudmVyYm9zaXR5ID09IDApIHtcbiAgICAgICAgICBwcm9wcy5zZXRWZXJib3NpdHkoMSlcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBwcm9wcy5zZXRWZXJib3NpdHkoMClcbiAgICAgICAgfVxuXG4gICAgICB9IGVsc2UgaWYgKHNwbGl0Q29tbWFuZFswXS50b0xvd2VyQ2FzZSgpID09IFwidmlld1wiKSB7XG4gICAgICAgIHJlc3BvbnNlID0gbG9hZFJlc3BvbnNlKHNwbGl0Q29tbWFuZClcbiAgICAgICAgVmlld091dHB1dChwcm9wcywgcHJvcHMuY3VycmVudERhdGFzZXQpXG5cbiAgICAgICAgLy8gVE9ETzogZGVmaW5lIGFub3RoZXIgY29tcG9uZW50IGNhbGxlZCB2aWV3IG91dHB1dCB0byBoYW5kbGUgdGhlIHZpZXcgc3R1ZmZcbiAgICAgICAgaGFuZGxlU3VibWl0KHBhcnNlZENvbW1hbmQpXG5cbiAgICAgIH0gZWxzZSBpZiAoc3BsaXRDb21tYW5kWzBdLnRvTG93ZXJDYXNlKCkgPT0gXCJzZWFyY2hcIikge1xuICAgICAgICByZXNwb25zZSA9IGxvYWRSZXNwb25zZShzcGxpdENvbW1hbmQpXG4gICAgICAgIGhhbmRsZVN1Ym1pdChwYXJzZWRDb21tYW5kKVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmVzcG9uc2UgPSBsb2FkUmVzcG9uc2Uoc3BsaXRDb21tYW5kKVxuICAgICAgICBoYW5kbGVTdWJtaXQoY29tbWFuZCArIFwiIGlzIG5vdCBhIHZhbGlkIGNvbW1hbmQuXCIpXG4gICAgICB9XG5cbiAgICB9XG5cbiAgICBmdW5jdGlvbiBoYW5kbGVTdWJtaXQoY29tbWFuZFN0cmluZyA6IHN0cmluZykge1xuICAgICAgc2V0Q291bnQoY291bnQgKyAxKTtcbiAgICAgIHByb3BzLnNldEhpc3RvcnkoWy4uLnByb3BzLmhpc3RvcnksIGNvbW1hbmRTdHJpbmddKTtcbiAgICB9XG4gICAgLy8gVE9ETzogT25jZSBpdCBpbmNyZW1lbnRzLCB0cnkgdG8gbWFrZSBpdCBwdXNoIGNvbW1hbmRzLi4uIE5vdGUgdGhhdCB5b3UgY2FuIHVzZSB0aGUgYC4uLmAgc3ByZWFkIHN5bnRheCB0byBjb3B5IHdoYXQgd2FzIHRoZXJlIGJlZm9yZVxuICAgIC8vIGFkZCB0byBpdCB3aXRoIG5ldyBjb21tYW5kcy5cbiAgICAvKipcbiAgICAgKiBXZSBzdWdnZXN0IGJyZWFraW5nIGRvd24gdGhpcyBjb21wb25lbnQgaW50byBzbWFsbGVyIGNvbXBvbmVudHMsIHRoaW5rIGFib3V0IHRoZSBpbmRpdmlkdWFsIHBpZWNlcyBcbiAgICAgKiBvZiB0aGUgUkVQTCBhbmQgaG93IHRoZXkgY29ubmVjdCB0byBlYWNoIG90aGVyLi4uXG4gICAgICovXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZXBsLWlucHV0XCI+XG4gICAgICAgICAgICB7LyogVGhpcyBpcyBhIGNvbW1lbnQgd2l0aGluIHRoZSBKU1guIE5vdGljZSB0aGF0IGl0J3MgYSBUeXBlU2NyaXB0IGNvbW1lbnQgd3JhcHBlZCBpblxuICAgICAgICAgICAgYnJhY2VzLCBzbyB0aGF0IFJlYWN0IGtub3dzIGl0IHNob3VsZCBiZSBpbnRlcnByZXRlZCBhcyBUeXBlU2NyaXB0ICovfVxuICAgICAgICAgICAgey8qIEkgb3B0ZWQgdG8gdXNlIHRoaXMgSFRNTCB0YWc7IHlvdSBkb24ndCBuZWVkIHRvLiBJdCBzdHJ1Y3R1cmVzIG11bHRpcGxlIGlucHV0IGZpZWxkc1xuICAgICAgICAgICAgaW50byBhIHNpbmdsZSB1bml0LCB3aGljaCBtYWtlcyBpdCBlYXNpZXIgZm9yIHNjcmVlbnJlYWRlcnMgdG8gbmF2aWdhdGUuICovfVxuICAgICAgICAgICAgPGZpZWxkc2V0PlxuICAgICAgICAgICAgICA8bGVnZW5kPkVudGVyIGEgY29tbWFuZDo8L2xlZ2VuZD5cbiAgICAgICAgICAgICAgPENvbnRyb2xsZWRJbnB1dCB2YWx1ZT17Y29tbWFuZFN0cmluZ30gc2V0VmFsdWU9e3NldENvbW1hbmRTdHJpbmd9IGFyaWFMYWJlbD17XCJDb21tYW5kIGlucHV0XCJ9Lz5cbiAgICAgICAgICAgIDwvZmllbGRzZXQ+XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudCA9IFwicHJpbWFyeVwiIGFyaWEtbGFiZWw9J3N1Ym1pdC1idXR0b24nIG9uQ2xpY2sgPSB7KCkgPT4gaGFuZGxlKGNvbW1hbmRTdHJpbmcpfT5TdWJtaXR0ZWQge2NvdW50fSA8L0J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfSJdLCJmaWxlIjoiL1VzZXJzL3NlYW4vRG9jdW1lbnRzL2NzMzIvbW9jay1tc3VuNTktc3l1NjYvbW9jay9zcmMvY29tcG9uZW50cy9SRVBMSW5wdXQudHN4In0=