import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=77b84e45"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/michaelsun/cs32/mock-gearup/mock/src/components/REPLInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/src/styles/main.css";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=77b84e45"; const useState = __vite__cjsImport4_react["useState"];
import { ControlledInput } from "/src/components/ControlledInput.tsx";
export function REPLInput(props) {
  _s();
  const [commandString, setCommandString] = useState("");
  const [count, setCount] = useState(0);
  function handleSubmit(commandString2) {
    setCount(count + 1);
    props.setHistory([...props.history, commandString2]);
    setCommandString("");
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-input", children: [
    /* @__PURE__ */ jsxDEV("fieldset", { children: [
      /* @__PURE__ */ jsxDEV("legend", { children: "Enter a command:" }, void 0, false, {
        fileName: "/Users/michaelsun/cs32/mock-gearup/mock/src/components/REPLInput.tsx",
        lineNumber: 38,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV(ControlledInput, { value: commandString, setValue: setCommandString, ariaLabel: "Command input" }, void 0, false, {
        fileName: "/Users/michaelsun/cs32/mock-gearup/mock/src/components/REPLInput.tsx",
        lineNumber: 39,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/michaelsun/cs32/mock-gearup/mock/src/components/REPLInput.tsx",
      lineNumber: 37,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("button", { onClick: () => handleSubmit(commandString), children: [
      "Submitted ",
      count,
      " times"
    ] }, void 0, true, {
      fileName: "/Users/michaelsun/cs32/mock-gearup/mock/src/components/REPLInput.tsx",
      lineNumber: 42,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/michaelsun/cs32/mock-gearup/mock/src/components/REPLInput.tsx",
    lineNumber: 32,
    columnNumber: 10
  }, this);
}
_s(REPLInput, "LHtx53y6unkZPs3I8ZC4Ys5ix/8=");
_c = REPLInput;
var _c;
$RefreshReg$(_c, "REPLInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/michaelsun/cs32/mock-gearup/mock/src/components/REPLInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUNjOzs7Ozs7Ozs7Ozs7Ozs7OztBQXJDZCxPQUFPO0FBQ1AsU0FBbUNBLGdCQUFlO0FBQ2xELFNBQVNDLHVCQUF1QjtBQVV6QixnQkFBU0MsVUFBVUMsT0FBd0I7QUFBQUMsS0FBQTtBQUc5QyxRQUFNLENBQUNDLGVBQWVDLGdCQUFnQixJQUFJTixTQUFpQixFQUFFO0FBRTdELFFBQU0sQ0FBQ08sT0FBT0MsUUFBUSxJQUFJUixTQUFpQixDQUFDO0FBRzVDLFdBQVNTLGFBQWFKLGdCQUFzQjtBQUMxQ0csYUFBU0QsUUFBTSxDQUFDO0FBRWhCSixVQUFNTyxXQUFXLENBQUMsR0FBR1AsTUFBTVEsU0FBU04sY0FBYSxDQUFDO0FBQ2xEQyxxQkFBaUIsRUFBRTtBQUFBLEVBQ3JCO0FBS0EsU0FDSSx1QkFBQyxTQUFJLFdBQVUsY0FLWDtBQUFBLDJCQUFDLGNBQ0M7QUFBQSw2QkFBQyxZQUFPLGdDQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0I7QUFBQSxNQUN4Qix1QkFBQyxtQkFBZ0IsT0FBT0QsZUFBZSxVQUFVQyxrQkFBa0IsV0FBVyxtQkFBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4RjtBQUFBLFNBRmhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBRUEsdUJBQUMsWUFBTyxTQUFTLE1BQU1HLGFBQWFKLGFBQWEsR0FBRztBQUFBO0FBQUEsTUFBV0U7QUFBQUEsTUFBTTtBQUFBLFNBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkU7QUFBQSxPQVYvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBV0E7QUFFTjtBQUFDSCxHQWhDYUYsV0FBUztBQUFBVSxLQUFUVjtBQUFTLElBQUFVO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkNvbnRyb2xsZWRJbnB1dCIsIlJFUExJbnB1dCIsInByb3BzIiwiX3MiLCJjb21tYW5kU3RyaW5nIiwic2V0Q29tbWFuZFN0cmluZyIsImNvdW50Iiwic2V0Q291bnQiLCJoYW5kbGVTdWJtaXQiLCJzZXRIaXN0b3J5IiwiaGlzdG9yeSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUkVQTElucHV0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgJy4uL3N0eWxlcy9tYWluLmNzcyc7XG5pbXBvcnQgeyBEaXNwYXRjaCwgU2V0U3RhdGVBY3Rpb24sIHVzZVN0YXRlfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBDb250cm9sbGVkSW5wdXQgfSBmcm9tICcuL0NvbnRyb2xsZWRJbnB1dCc7XG5cbmludGVyZmFjZSBSRVBMSW5wdXRQcm9wc3tcbiAgLy8gVE9ETzogRmlsbCB0aGlzIHdpdGggZGVzaXJlZCBwcm9wcy4uLiBNYXliZSBzb21ldGhpbmcgdG8ga2VlcCB0cmFjayBvZiB0aGUgc3VibWl0dGVkIGNvbW1hbmRzXG4gIC8vIENIQU5HRURcbiAgaGlzdG9yeTogc3RyaW5nW10sXG4gIHNldEhpc3Rvcnk6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPHN0cmluZ1tdPj4sXG59XG4vLyBZb3UgY2FuIHVzZSBhIGN1c3RvbSBpbnRlcmZhY2Ugb3IgZXhwbGljaXQgZmllbGRzIG9yIGJvdGghIEFuIGFsdGVybmF0aXZlIHRvIHRoZSBjdXJyZW50IGZ1bmN0aW9uIGhlYWRlciBtaWdodCBiZTpcbi8vIFJFUExJbnB1dChoaXN0b3J5OiBzdHJpbmdbXSwgc2V0SGlzdG9yeTogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248c3RyaW5nW10+PilcbmV4cG9ydCBmdW5jdGlvbiBSRVBMSW5wdXQocHJvcHMgOiBSRVBMSW5wdXRQcm9wcykge1xuICAgIC8vIFJlbWVtYmVyOiBsZXQgUmVhY3QgbWFuYWdlIHN0YXRlIGluIHlvdXIgd2ViYXBwLiBcbiAgICAvLyBNYW5hZ2VzIHRoZSBjb250ZW50cyBvZiB0aGUgaW5wdXQgYm94XG4gICAgY29uc3QgW2NvbW1hbmRTdHJpbmcsIHNldENvbW1hbmRTdHJpbmddID0gdXNlU3RhdGU8c3RyaW5nPignJyk7XG4gICAgLy8gTWFuYWdlcyB0aGUgY3VycmVudCBhbW91bnQgb2YgdGltZXMgdGhlIGJ1dHRvbiBpcyBjbGlja2VkXG4gICAgY29uc3QgW2NvdW50LCBzZXRDb3VudF0gPSB1c2VTdGF0ZTxudW1iZXI+KDApO1xuICAgIFxuICAgIC8vIFRoaXMgZnVuY3Rpb24gaXMgdHJpZ2dlcmVkIHdoZW4gdGhlIGJ1dHRvbiBpcyBjbGlja2VkLlxuICAgIGZ1bmN0aW9uIGhhbmRsZVN1Ym1pdChjb21tYW5kU3RyaW5nOnN0cmluZykge1xuICAgICAgc2V0Q291bnQoY291bnQrMSlcbiAgICAgIC8vIENIQU5HRURcbiAgICAgIHByb3BzLnNldEhpc3RvcnkoWy4uLnByb3BzLmhpc3RvcnksIGNvbW1hbmRTdHJpbmddKVxuICAgICAgc2V0Q29tbWFuZFN0cmluZygnJylcbiAgICB9XG4gICAgLyoqXG4gICAgICogV2Ugc3VnZ2VzdCBicmVha2luZyBkb3duIHRoaXMgY29tcG9uZW50IGludG8gc21hbGxlciBjb21wb25lbnRzLCB0aGluayBhYm91dCB0aGUgaW5kaXZpZHVhbCBwaWVjZXMgXG4gICAgICogb2YgdGhlIFJFUEwgYW5kIGhvdyB0aGV5IGNvbm5lY3QgdG8gZWFjaCBvdGhlci4uLlxuICAgICAqL1xuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVwbC1pbnB1dFwiPlxuICAgICAgICAgICAgey8qIFRoaXMgaXMgYSBjb21tZW50IHdpdGhpbiB0aGUgSlNYLiBOb3RpY2UgdGhhdCBpdCdzIGEgVHlwZVNjcmlwdCBjb21tZW50IHdyYXBwZWQgaW5cbiAgICAgICAgICAgIGJyYWNlcywgc28gdGhhdCBSZWFjdCBrbm93cyBpdCBzaG91bGQgYmUgaW50ZXJwcmV0ZWQgYXMgVHlwZVNjcmlwdCAqL31cbiAgICAgICAgICAgIHsvKiBJIG9wdGVkIHRvIHVzZSB0aGlzIEhUTUwgdGFnOyB5b3UgZG9uJ3QgbmVlZCB0by4gSXQgc3RydWN0dXJlcyBtdWx0aXBsZSBpbnB1dCBmaWVsZHNcbiAgICAgICAgICAgIGludG8gYSBzaW5nbGUgdW5pdCwgd2hpY2ggbWFrZXMgaXQgZWFzaWVyIGZvciBzY3JlZW5yZWFkZXJzIHRvIG5hdmlnYXRlLiAqL31cbiAgICAgICAgICAgIDxmaWVsZHNldD5cbiAgICAgICAgICAgICAgPGxlZ2VuZD5FbnRlciBhIGNvbW1hbmQ6PC9sZWdlbmQ+XG4gICAgICAgICAgICAgIDxDb250cm9sbGVkSW5wdXQgdmFsdWU9e2NvbW1hbmRTdHJpbmd9IHNldFZhbHVlPXtzZXRDb21tYW5kU3RyaW5nfSBhcmlhTGFiZWw9e1wiQ29tbWFuZCBpbnB1dFwifS8+XG4gICAgICAgICAgICA8L2ZpZWxkc2V0PlxuICAgICAgICAgICAgey8qIFRPRE86IEN1cnJlbnRseSB0aGlzIGJ1dHRvbiBqdXN0IGNvdW50cyB1cCwgY2FuIHdlIG1ha2UgaXQgcHVzaCB0aGUgY29udGVudHMgb2YgdGhlIGlucHV0IGJveCB0byB0aGUgaGlzdG9yeT8qL31cbiAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gaGFuZGxlU3VibWl0KGNvbW1hbmRTdHJpbmcpfT5TdWJtaXR0ZWQge2NvdW50fSB0aW1lczwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICApO1xuICB9Il0sImZpbGUiOiIvVXNlcnMvbWljaGFlbHN1bi9jczMyL21vY2stZ2VhcnVwL21vY2svc3JjL2NvbXBvbmVudHMvUkVQTElucHV0LnRzeCJ9