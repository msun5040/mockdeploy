import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLHistory.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8e8a8cac"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/REPLHistory.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css?t=1697122193990";
export function REPLHistory(props) {
  console.log(props);
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-history", children: props.history.map((logEntrance) => logEntrance) }, void 0, false, {
    fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/REPLHistory.tsx",
    lineNumber: 9,
    columnNumber: 10
  }, this);
}
_c = REPLHistory;
var _c;
$RefreshReg$(_c, "REPLHistory");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/REPLHistory.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWVE7QUFaUiwyQkFBbUJBO0FBQXNCLE1BQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNoRCxPQUFPO0FBT0EsZ0JBQVNDLFlBQVlDLE9BQTBCO0FBQ2xEQyxVQUFRQyxJQUFJRixLQUFLO0FBRWpCLFNBQ0ksdUJBQUMsU0FBSSxXQUFVLGdCQUVWQSxnQkFBTUcsUUFBUUMsSUFBSUMsaUJBQWVBLFdBQVcsS0FGakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUlBO0FBRVI7QUFBQ0MsS0FWZVA7QUFBVyxJQUFBTztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiU2V0U3RhdGVBY3Rpb24iLCJSRVBMSGlzdG9yeSIsInByb3BzIiwiY29uc29sZSIsImxvZyIsImhpc3RvcnkiLCJtYXAiLCJsb2dFbnRyYW5jZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUkVQTEhpc3RvcnkudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IERpc3BhdGNoLCBTZXRTdGF0ZUFjdGlvbiB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCAnLi4vc3R5bGVzL21haW4uY3NzJztcblxuaW50ZXJmYWNlIFJFUExIaXN0b3J5UHJvcHN7XG4gICAgLy8gVE9ETzogRmlsbCB3aXRoIHNvbWUgc2hhcmVkIHN0YXRlIHRyYWNraW5nIGFsbCB0aGUgcHVzaGVkIGNvbW1hbmRzXG4gICAgaGlzdG9yeTogSlNYLkVsZW1lbnRbXVxuXG59XG5leHBvcnQgZnVuY3Rpb24gUkVQTEhpc3RvcnkocHJvcHMgOiBSRVBMSGlzdG9yeVByb3BzKSB7XG4gICAgY29uc29sZS5sb2cocHJvcHMpXG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlcGwtaGlzdG9yeVwiPlxuICAgICAgICAgICAgey8qIFRoaXMgaXMgd2hlcmUgY29tbWFuZCBoaXN0b3J5IHdpbGwgZ28gKi99XG4gICAgICAgICAgICB7cHJvcHMuaGlzdG9yeS5tYXAobG9nRW50cmFuY2UgPT4gbG9nRW50cmFuY2UpfVxuICAgICAgICAgICAgXG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59Il0sImZpbGUiOiIvVXNlcnMvc2Vhbi9Eb2N1bWVudHMvY3MzMi9tb2NrLW1zdW41OS1zeXU2Ni9tb2NrL3NyYy9jb21wb25lbnRzL1JFUExIaXN0b3J5LnRzeCJ9