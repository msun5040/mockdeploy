import {
  require_react
} from "/node_modules/.vite/deps/chunk-MYQCFY5U.js?v=8e8a8cac";
export default require_react();
//# sourceMappingURL=react.js.map
