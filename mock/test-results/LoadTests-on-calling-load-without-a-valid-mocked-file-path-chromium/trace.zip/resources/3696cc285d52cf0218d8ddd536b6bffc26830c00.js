import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/LoadOutput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8e8a8cac"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/LoadOutput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
function successResponseMap(response) {
  return [/* @__PURE__ */ jsxDEV("li", { "aria-label": "load-success-response", children: "Response Type: " + response["type"] }, void 0, false, {
    fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/LoadOutput.tsx",
    lineNumber: 14,
    columnNumber: 11
  }, this), /* @__PURE__ */ jsxDEV("li", { children: response["type"] + ": " + JSON.stringify(response["data"]) }, void 0, false, {
    fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/LoadOutput.tsx",
    lineNumber: 14,
    columnNumber: 95
  }, this)];
}
function errorResponseMap(response) {
  return [/* @__PURE__ */ jsxDEV("li", { "aria-label": "load-error-response", children: "Response Type: " + response["type"] }, void 0, false, {
    fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/LoadOutput.tsx",
    lineNumber: 17,
    columnNumber: 11
  }, this), /* @__PURE__ */ jsxDEV("li", { children: response["type"] + ": " + JSON.stringify(response["error_message"]) }, void 0, false, {
    fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/LoadOutput.tsx",
    lineNumber: 17,
    columnNumber: 93
  }, this)];
}
export function LoadOutput(command, props, response) {
  let contentResponse;
  let concatenatedResponse;
  console.log("type:" + response.type);
  if (response.type == "success") {
    contentResponse = successResponseMap(response);
  } else if (response.type == "error") {
    contentResponse = errorResponseMap(response);
  } else {
    props.setResponses([...props.responses, /* @__PURE__ */ jsxDEV("div", { className: "error-message", "aria-label": "load-error", children: /* @__PURE__ */ jsxDEV("p", { children: /* @__PURE__ */ jsxDEV("b", { children: "load_csv requires a valid filepath" }, void 0, false, {
      fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/LoadOutput.tsx",
      lineNumber: 34,
      columnNumber: 14
    }, this) }, void 0, false, {
      fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/LoadOutput.tsx",
      lineNumber: 34,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/LoadOutput.tsx",
      lineNumber: 33,
      columnNumber: 45
    }, this), /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
      fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/LoadOutput.tsx",
      lineNumber: 35,
      columnNumber: 17
    }, this)]);
    return;
  }
  if (props.toggle == 0) {
    concatenatedResponse = /* @__PURE__ */ jsxDEV("div", { "aria-label": "load-response", children: /* @__PURE__ */ jsxDEV("p", { "aria-label": "brief-label", children: [
      /* @__PURE__ */ jsxDEV("b", { children: "Brief Output: " }, void 0, false, {
        fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/LoadOutput.tsx",
        lineNumber: 43,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("ul", { "aria-label": "load-response-map", children: contentResponse }, void 0, false, {
        fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/LoadOutput.tsx",
        lineNumber: 44,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/LoadOutput.tsx",
      lineNumber: 42,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/LoadOutput.tsx",
      lineNumber: 41,
      columnNumber: 28
    }, this);
  } else if (props.toggle == 1) {
    concatenatedResponse = /* @__PURE__ */ jsxDEV("div", { "aria-label": "load-response", children: /* @__PURE__ */ jsxDEV("p", { children: [
      /* @__PURE__ */ jsxDEV("b", { "aria-label": "verbose-label", children: "Verbose Output: " }, void 0, false, {
        fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/LoadOutput.tsx",
        lineNumber: 55,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("ul", { "aria-label": "load-response-map", children: [
        /* @__PURE__ */ jsxDEV("li", { children: "Command: " + command }, void 0, false, {
          fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/LoadOutput.tsx",
          lineNumber: 57,
          columnNumber: 13
        }, this),
        contentResponse
      ] }, void 0, true, {
        fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/LoadOutput.tsx",
        lineNumber: 56,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/LoadOutput.tsx",
      lineNumber: 54,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/LoadOutput.tsx",
      lineNumber: 53,
      columnNumber: 28
    }, this);
  } else {
    concatenatedResponse = /* @__PURE__ */ jsxDEV("div", { children: " this isn't right... " }, void 0, false, {
      fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/LoadOutput.tsx",
      lineNumber: 63,
      columnNumber: 28
    }, this);
  }
  props.setResponses([...props.responses, concatenatedResponse, /* @__PURE__ */ jsxDEV("hr", { "aria-label": "command-separator" }, void 0, false, {
    fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/LoadOutput.tsx",
    lineNumber: 65,
    columnNumber: 65
  }, this)]);
}
_c = LoadOutput;
var _c;
$RefreshReg$(_c, "LoadOutput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/LoadOutput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0JJO0FBbEJKLDJCQUFtQkE7QUFBd0IsTUFBTyxjQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFnQnpELFNBQVNDLG1CQUFtQkMsVUFBdUI7QUFDakQsU0FBUSxDQUNOLHVCQUFDLFFBQUcsY0FBYSx5QkFBeUIsOEJBQW9CQSxTQUFTLE1BQU0sS0FBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFnRixHQUNoRix1QkFBQyxRQUFJQSxtQkFBUyxNQUFNLElBQUksT0FBT0MsS0FBS0MsVUFBVUYsU0FBUyxNQUFNLENBQUMsS0FBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFnRSxDQUFLO0FBRXpFO0FBRUEsU0FBU0csaUJBQWlCSCxVQUF1QjtBQUM3QyxTQUFRLENBQ04sdUJBQUMsUUFBRyxjQUFhLHVCQUF1Qiw4QkFBb0JBLFNBQVMsTUFBTSxLQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQThFLEdBQzlFLHVCQUFDLFFBQUlBLG1CQUFTLE1BQU0sSUFBSSxPQUFPQyxLQUFLQyxVQUFVRixTQUFTLGVBQWUsQ0FBQyxLQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXlFLENBQUs7QUFFbEY7QUFFSyxnQkFBU0ksV0FBV0MsU0FBa0JDLE9BQXlCTixVQUF1QjtBQUt6RixNQUFJTztBQUNKLE1BQUlDO0FBQ0pDLFVBQVFDLElBQUksVUFBVVYsU0FBU1csSUFBSTtBQUNuQyxNQUFJWCxTQUFTVyxRQUFRLFdBQVU7QUFDM0JKLHNCQUFrQlIsbUJBQW1CQyxRQUFRO0FBQUEsRUFDakQsV0FBV0EsU0FBU1csUUFBUSxTQUFTO0FBQ2pDSixzQkFBa0JKLGlCQUFpQkgsUUFBUTtBQUFBLEVBQy9DLE9BQU87QUFFTE0sVUFBTU0sYUFBYSxDQUNqQixHQUFHTixNQUFNTyxXQUVULHVCQUFDLFNBQUksV0FBYSxpQkFBaUIsY0FBYSxjQUM5QyxpQ0FBQyxPQUFFLGlDQUFDLE9BQUUsa0RBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxQyxLQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRDLEtBRDlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxHQUVGLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFJLENBQUssQ0FBQztBQUNWO0FBQUEsRUFDRjtBQUdBLE1BQUlQLE1BQU1RLFVBQVUsR0FBRztBQUNyQk4sMkJBQ0EsdUJBQUMsU0FBSSxjQUFhLGlCQUNoQixpQ0FBQyxPQUFFLGNBQWEsZUFDZDtBQUFBLDZCQUFDLE9BQUUsOEJBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQjtBQUFBLE1BQ2pCLHVCQUFDLFFBQUcsY0FBYSxxQkFDZEQsNkJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxFQUNGLFdBR1NELE1BQU1RLFVBQVUsR0FBRztBQUMxQk4sMkJBQ0EsdUJBQUMsU0FBSSxjQUFhLGlCQUNoQixpQ0FBQyxPQUNDO0FBQUEsNkJBQUMsT0FBRSxjQUFhLGlCQUFnQixnQ0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnRDtBQUFBLE1BQ2hELHVCQUFDLFFBQUcsY0FBYSxxQkFDZjtBQUFBLCtCQUFDLFFBQUksd0JBQWNILFdBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkI7QUFBQSxRQUMxQkU7QUFBQUEsV0FGSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQTtBQUFBLEVBQ0YsT0FDSztBQUNIQywyQkFBdUIsdUJBQUMsU0FBSSxxQ0FBTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBCO0FBQUEsRUFDbkQ7QUFDRUYsUUFBTU0sYUFBYSxDQUFDLEdBQUdOLE1BQU1PLFdBQVdMLHNCQUN4Qyx1QkFBQyxRQUFHLGNBQWEsdUJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBcUMsQ0FBSyxDQUFDO0FBRTdDO0FBQUNPLEtBekRXWDtBQUFVLElBQUFXO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJTZXRTdGF0ZUFjdGlvbiIsInN1Y2Nlc3NSZXNwb25zZU1hcCIsInJlc3BvbnNlIiwiSlNPTiIsInN0cmluZ2lmeSIsImVycm9yUmVzcG9uc2VNYXAiLCJMb2FkT3V0cHV0IiwiY29tbWFuZCIsInByb3BzIiwiY29udGVudFJlc3BvbnNlIiwiY29uY2F0ZW5hdGVkUmVzcG9uc2UiLCJjb25zb2xlIiwibG9nIiwidHlwZSIsInNldFJlc3BvbnNlcyIsInJlc3BvbnNlcyIsInRvZ2dsZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiTG9hZE91dHB1dC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRGlzcGF0Y2gsIFNldFN0YXRlQWN0aW9uLCB1c2VTdGF0ZX0gZnJvbSAncmVhY3QnO1xuXG5pbnRlcmZhY2UgUkVQTE91dHB1dFByb3Bze1xuICAgIC8vIFRPRE86IEZpbGwgdGhpcyB3aXRoIGRlc2lyZWQgcHJvcHMuLi4gTWF5YmUgc29tZXRoaW5nIHRvIGtlZXAgdHJhY2sgb2YgdGhlIHN1Ym1pdHRlZCBjb21tYW5kc1xuICAgIHRvZ2dsZTogbnVtYmVyXG4gICAgcmVzcG9uc2VzOiBKU1guRWxlbWVudFtdXG4gICAgc2V0UmVzcG9uc2VzOiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxKU1guRWxlbWVudFtdPj5cbiAgfVxuXG5pbnRlcmZhY2UgUmVzcG9uc2VNYXAge1xuICB0eXBlOiBzdHJpbmdcbiAgZGF0YTogSlNPTlxuICBlcnJvcl9tZXNzYWdlOiBzdHJpbmdcbn1cblxuXG5mdW5jdGlvbiBzdWNjZXNzUmVzcG9uc2VNYXAocmVzcG9uc2U6IFJlc3BvbnNlTWFwKSB7XG4gIHJldHVybiAoW1xuICAgIDxsaSBhcmlhLWxhYmVsID0gXCJsb2FkLXN1Y2Nlc3MtcmVzcG9uc2VcIj57XCJSZXNwb25zZSBUeXBlOiBcIisgIHJlc3BvbnNlW1widHlwZVwiXSB9PC9saT4sIFxuICAgIDxsaT57cmVzcG9uc2VbXCJ0eXBlXCJdICsgXCI6IFwiICsgSlNPTi5zdHJpbmdpZnkocmVzcG9uc2VbXCJkYXRhXCJdKX08L2xpPlxuICBdKVxufVxuXG5mdW5jdGlvbiBlcnJvclJlc3BvbnNlTWFwKHJlc3BvbnNlOiBSZXNwb25zZU1hcCkge1xuICAgIHJldHVybiAoW1xuICAgICAgPGxpIGFyaWEtbGFiZWwgPSBcImxvYWQtZXJyb3ItcmVzcG9uc2VcIj57XCJSZXNwb25zZSBUeXBlOiBcIisgIHJlc3BvbnNlW1widHlwZVwiXSB9PC9saT4sIFxuICAgICAgPGxpPntyZXNwb25zZVtcInR5cGVcIl0gKyBcIjogXCIgKyBKU09OLnN0cmluZ2lmeShyZXNwb25zZVtcImVycm9yX21lc3NhZ2VcIl0pfTwvbGk+XG4gICAgXSlcbiAgfVxuXG5leHBvcnQgZnVuY3Rpb24gTG9hZE91dHB1dChjb21tYW5kIDogc3RyaW5nLCBwcm9wcyA6IFJFUExPdXRwdXRQcm9wcywgcmVzcG9uc2UgOiBSZXNwb25zZU1hcCl7XG4gICAgLy8gY29uc29sZS5sb2coY29tbWFuZClcbiAgICAvLyBjb25zb2xlLmxvZyhwcm9wcylcbiAgICAvLyBjb25zb2xlLmxvZyhyZXNwb25zZSlcblxuICAgIGxldCBjb250ZW50UmVzcG9uc2UgOiBKU1guRWxlbWVudFtdXG4gICAgbGV0IGNvbmNhdGVuYXRlZFJlc3BvbnNlIDogSlNYLkVsZW1lbnQ7XG4gICAgY29uc29sZS5sb2coXCJ0eXBlOlwiICsgcmVzcG9uc2UudHlwZSlcbiAgICBpZiAocmVzcG9uc2UudHlwZSA9PSBcInN1Y2Nlc3NcIil7XG4gICAgICAgIGNvbnRlbnRSZXNwb25zZSA9IHN1Y2Nlc3NSZXNwb25zZU1hcChyZXNwb25zZSlcbiAgICB9IGVsc2UgaWYgKHJlc3BvbnNlLnR5cGUgPT0gXCJlcnJvclwiKSB7XG4gICAgICAgIGNvbnRlbnRSZXNwb25zZSA9IGVycm9yUmVzcG9uc2VNYXAocmVzcG9uc2UpXG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIHNob3VsZCBuZXZlciBoYXBwZW5cbiAgICAgIHByb3BzLnNldFJlc3BvbnNlcyhbXG4gICAgICAgIC4uLnByb3BzLnJlc3BvbnNlcywgXG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWUgPSB7J2Vycm9yLW1lc3NhZ2UnfSBhcmlhLWxhYmVsPSB7J2xvYWQtZXJyb3InfT5cbiAgICAgICAgICA8cD48Yj5sb2FkX2NzdiByZXF1aXJlcyBhIHZhbGlkIGZpbGVwYXRoPC9iPjwvcD5cbiAgICAgICAgPC9kaXY+LCBcblxuICAgICAgPGhyPjwvaHI+XSk7XG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICAvLyB2ZXJib3NlIHNldHRpbmdcbiAgICBpZiAocHJvcHMudG9nZ2xlID09IDApIHtcbiAgICAgIGNvbmNhdGVuYXRlZFJlc3BvbnNlID0gXG4gICAgICA8ZGl2IGFyaWEtbGFiZWwgPSBcImxvYWQtcmVzcG9uc2VcIj5cbiAgICAgICAgPHAgYXJpYS1sYWJlbCA9IFwiYnJpZWYtbGFiZWxcIj5cbiAgICAgICAgICA8Yj5CcmllZiBPdXRwdXQ6IDwvYj5cbiAgICAgICAgICA8dWwgYXJpYS1sYWJlbCA9IFwibG9hZC1yZXNwb25zZS1tYXBcIj5cbiAgICAgICAgICAgIHtjb250ZW50UmVzcG9uc2V9XG4gICAgICAgICAgPC91bD5cbiAgICAgICAgPC9wPlxuICAgICAgPC9kaXY+XG4gICAgfVxuXG4gICAgLy8gbm9uLXZlcmJvc2Ugc2V0dGluZ1xuICAgIGVsc2UgaWYgKHByb3BzLnRvZ2dsZSA9PSAxKSB7XG4gICAgICBjb25jYXRlbmF0ZWRSZXNwb25zZSA9IFxuICAgICAgPGRpdiBhcmlhLWxhYmVsID0gXCJsb2FkLXJlc3BvbnNlXCI+XG4gICAgICAgIDxwPlxuICAgICAgICAgIDxiIGFyaWEtbGFiZWwgPSBcInZlcmJvc2UtbGFiZWxcIj5WZXJib3NlIE91dHB1dDogPC9iPlxuICAgICAgICAgIDx1bCBhcmlhLWxhYmVsID0gXCJsb2FkLXJlc3BvbnNlLW1hcFwiPlxuICAgICAgICAgICAgPGxpPntcIkNvbW1hbmQ6IFwiICsgY29tbWFuZH08L2xpPlxuICAgICAgICAgICAge2NvbnRlbnRSZXNwb25zZX1cbiAgICAgICAgICA8L3VsPlxuICAgICAgICA8L3A+XG4gICAgICA8L2Rpdj5cbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICBjb25jYXRlbmF0ZWRSZXNwb25zZSA9IDxkaXY+IHRoaXMgaXNuJ3QgcmlnaHQuLi4gPC9kaXY+XG4gICAgfVxuICAgICAgcHJvcHMuc2V0UmVzcG9uc2VzKFsuLi5wcm9wcy5yZXNwb25zZXMsIGNvbmNhdGVuYXRlZFJlc3BvbnNlLCBcbiAgICAgIDxociBhcmlhLWxhYmVsID0gXCJjb21tYW5kLXNlcGFyYXRvclwiPjwvaHI+XSlcblxuICAgIH1cblxuXG5cblxuIl0sImZpbGUiOiIvVXNlcnMvc2Vhbi9Eb2N1bWVudHMvY3MzMi9tb2NrLW1zdW41OS1zeXU2Ni9tb2NrL3NyYy9jb21wb25lbnRzL0xvYWRPdXRwdXQudHN4In0=