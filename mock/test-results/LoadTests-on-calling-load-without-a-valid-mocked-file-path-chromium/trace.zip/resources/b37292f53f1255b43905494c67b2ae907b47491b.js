"use client";
import {
  Button_default
} from "/node_modules/.vite/deps/chunk-ARGI3ARW.js?v=8e8a8cac";
import {
  require_classnames,
  useBootstrapPrefix
} from "/node_modules/.vite/deps/chunk-YP6ZGVO3.js?v=8e8a8cac";
import {
  require_jsx_runtime
} from "/node_modules/.vite/deps/chunk-2ZZPWDJ7.js?v=8e8a8cac";
import {
  __toESM,
  require_react
} from "/node_modules/.vite/deps/chunk-MYQCFY5U.js?v=8e8a8cac";

// node_modules/react-bootstrap/esm/ToggleButton.js
var import_classnames = __toESM(require_classnames());
var React = __toESM(require_react());
var import_jsx_runtime = __toESM(require_jsx_runtime());
var import_jsx_runtime2 = __toESM(require_jsx_runtime());
var import_jsx_runtime3 = __toESM(require_jsx_runtime());
var noop = () => void 0;
var ToggleButton = React.forwardRef(({
  bsPrefix,
  name,
  className,
  checked,
  type,
  onChange,
  value,
  disabled,
  id,
  inputRef,
  ...props
}, ref) => {
  bsPrefix = useBootstrapPrefix(bsPrefix, "btn-check");
  return (0, import_jsx_runtime3.jsxs)(import_jsx_runtime2.Fragment, {
    children: [(0, import_jsx_runtime.jsx)("input", {
      className: bsPrefix,
      name,
      type,
      value,
      ref: inputRef,
      autoComplete: "off",
      checked: !!checked,
      disabled: !!disabled,
      onChange: onChange || noop,
      id
    }), (0, import_jsx_runtime.jsx)(Button_default, {
      ...props,
      ref,
      className: (0, import_classnames.default)(className, disabled && "disabled"),
      type: void 0,
      role: void 0,
      as: "label",
      htmlFor: id
    })]
  });
});
ToggleButton.displayName = "ToggleButton";
var ToggleButton_default = ToggleButton;
export {
  ToggleButton_default as default
};
//# sourceMappingURL=react-bootstrap_ToggleButton.js.map
