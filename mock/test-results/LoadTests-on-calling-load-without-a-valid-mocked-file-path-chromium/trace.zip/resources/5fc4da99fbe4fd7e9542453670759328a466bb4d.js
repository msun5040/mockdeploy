import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/VerbosityController.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8e8a8cac"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/VerbosityController.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import ToggleButton from "/node_modules/.vite/deps/react-bootstrap_ToggleButton.js?v=8e8a8cac";
export function VerbosityController(prop) {
  function toggleVerbosity() {
    if (prop.toggle == 0) {
      prop.setToggle(1);
    } else {
      prop.setToggle(0);
    }
  }
  return /* @__PURE__ */ jsxDEV(ToggleButton, { id: "verbosity-control", value: prop.toggle, onClick: () => toggleVerbosity(), children: prop.toggle == 0 ? "brief" : "verbose" }, void 0, false, {
    fileName: "/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/VerbosityController.tsx",
    lineNumber: 18,
    columnNumber: 10
  }, this);
}
_c = VerbosityController;
var _c;
$RefreshReg$(_c, "VerbosityController");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/sean/Documents/cs32/mock-msun59-syu66/mock/src/components/VerbosityController.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0JRO0FBcEJSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVBLE9BQU9BLGtCQUFrQjtBQU1sQixnQkFBU0Msb0JBQW9CQyxNQUF5QjtBQUN6RCxXQUFTQyxrQkFBbUI7QUFHeEIsUUFBSUQsS0FBS0UsVUFBVSxHQUFHO0FBQ2xCRixXQUFLRyxVQUFVLENBQUM7QUFBQSxJQUNwQixPQUFPO0FBQ0hILFdBQUtHLFVBQVUsQ0FBQztBQUFBLElBQ3BCO0FBQUEsRUFDSjtBQUVBLFNBQ0ksdUJBQUMsZ0JBQWEsSUFBSyxxQkFBb0IsT0FBU0gsS0FBS0UsUUFDckQsU0FBVyxNQUFNRCxnQkFBZ0IsR0FDNUJELGVBQUtFLFVBQVUsSUFBSSxVQUFVLGFBRmxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FHQTtBQUVSO0FBQUNFLEtBakJlTDtBQUFtQixJQUFBSztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiVG9nZ2xlQnV0dG9uIiwiVmVyYm9zaXR5Q29udHJvbGxlciIsInByb3AiLCJ0b2dnbGVWZXJib3NpdHkiLCJ0b2dnbGUiLCJzZXRUb2dnbGUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlZlcmJvc2l0eUNvbnRyb2xsZXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRPRE86IGltcGxlbWVudCB0aGUgcmFkaW8gYnV0dG9uIHRoYXQgY29udHJvbHMgdGhlIGJyZXZpdHkgb2YgdGhlIHJlc3BvbnNlLlxuaW1wb3J0IHsgRGlzcGF0Y2gsIFNldFN0YXRlQWN0aW9uIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IFRvZ2dsZUJ1dHRvbiBmcm9tICdyZWFjdC1ib290c3RyYXAvVG9nZ2xlQnV0dG9uJ1xuXG5pbnRlcmZhY2UgVmVyYm9zaXR5VG9nZ2xlciB7XG4gICAgdG9nZ2xlOiBudW1iZXJcbiAgICBzZXRUb2dnbGU6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPG51bWJlcj4+XG59XG5leHBvcnQgZnVuY3Rpb24gVmVyYm9zaXR5Q29udHJvbGxlcihwcm9wIDogVmVyYm9zaXR5VG9nZ2xlcikge1xuICAgIGZ1bmN0aW9uIHRvZ2dsZVZlcmJvc2l0eSAoKSB7XG4gICAgICAgIC8vIHRvZ2dsZSA9IDAgaXMgYnJpZWZcbiAgICAgICAgLy8gdG9nZ2xlID0gMSBpcyB2ZXJib3NlXG4gICAgICAgIGlmIChwcm9wLnRvZ2dsZSA9PSAwKSB7XG4gICAgICAgICAgICBwcm9wLnNldFRvZ2dsZSgxKVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcHJvcC5zZXRUb2dnbGUoMClcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiAoXG4gICAgICAgIDxUb2dnbGVCdXR0b24gaWQgPSAndmVyYm9zaXR5LWNvbnRyb2wnIHZhbHVlID0ge3Byb3AudG9nZ2xlfSBcbiAgICAgICAgb25DbGljayA9IHsoKSA9PiB0b2dnbGVWZXJib3NpdHkoKX0+XG4gICAgICAgICAgICB7cHJvcC50b2dnbGUgPT0gMCA/ICdicmllZicgOiAndmVyYm9zZSd9XG4gICAgICAgIDwvVG9nZ2xlQnV0dG9uPlxuICAgICk7XG59Il0sImZpbGUiOiIvVXNlcnMvc2Vhbi9Eb2N1bWVudHMvY3MzMi9tb2NrLW1zdW41OS1zeXU2Ni9tb2NrL3NyYy9jb21wb25lbnRzL1ZlcmJvc2l0eUNvbnRyb2xsZXIudHN4In0=