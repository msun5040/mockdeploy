import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/styles/main.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/Users/michaelsun/cs32/mock-gearup/mock/src/styles/main.css"
const __vite__css = "/*\n  This is a reasonable starting point for the CSS in Mock.\n  Positioning in CSS can sometimes be annoying to manage, so we've opted to \n  give you this starter CSS. Feel free to modify it as you wish, though.\n*/\n\n.repl {\n    position:relative;\n    min-height:95vh;    \n}\n\n.repl-history {      \n    height:55vh;   \n    margin: auto;\n    display: block;\n    overflow: scroll;    \n}\n\n.repl-input {        \n    margin: auto;    \n    height:10vh;\n}\n.repl-command-box {\n    width: 90%;            \n    margin: auto;\n    display: block;\n}\nbutton{\n    margin: auto;\n    display: block;\n}"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
export default __vite__css
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))