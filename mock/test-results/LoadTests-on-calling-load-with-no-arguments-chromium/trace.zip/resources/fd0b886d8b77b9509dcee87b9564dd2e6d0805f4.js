import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLHistory.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=77b84e45"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/michaelsun/cs32/mock-gearup/mock/src/components/REPLHistory.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css";
export function REPLHistory(props) {
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-history", children: props.history.map((command, index) => /* @__PURE__ */ jsxDEV("p", { children: command }, void 0, false, {
    fileName: "/Users/michaelsun/cs32/mock-gearup/mock/src/components/REPLHistory.tsx",
    lineNumber: 12,
    columnNumber: 52
  }, this)) }, void 0, false, {
    fileName: "/Users/michaelsun/cs32/mock-gearup/mock/src/components/REPLHistory.tsx",
    lineNumber: 8,
    columnNumber: 10
  }, this);
}
_c = REPLHistory;
var _c;
$RefreshReg$(_c, "REPLHistory");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/michaelsun/cs32/mock-gearup/mock/src/components/REPLHistory.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYW1EO0FBYm5ELE9BQU8sb0JBQW9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBT3BCLGdCQUFTQSxZQUFZQyxPQUEwQjtBQUNsRCxTQUNJLHVCQUFDLFNBQUksV0FBVSxnQkFJVkEsZ0JBQU1DLFFBQVFDLElBQUksQ0FBQ0MsU0FBU0MsVUFBVSx1QkFBQyxPQUFHRCxxQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQVksQ0FBSSxLQUozRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBS0E7QUFFUjtBQUFDRSxLQVRlTjtBQUFXLElBQUFNO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSRVBMSGlzdG9yeSIsInByb3BzIiwiaGlzdG9yeSIsIm1hcCIsImNvbW1hbmQiLCJpbmRleCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUkVQTEhpc3RvcnkudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAnLi4vc3R5bGVzL21haW4uY3NzJztcblxuaW50ZXJmYWNlIFJFUExIaXN0b3J5UHJvcHN7XG4gICAgLy8gVE9ETzogRmlsbCB3aXRoIHNvbWUgc2hhcmVkIHN0YXRlIHRyYWNraW5nIGFsbCB0aGUgcHVzaGVkIGNvbW1hbmRzXG4gICAgLy8gQ0hBTkdFRFxuICAgIGhpc3Rvcnk6IHN0cmluZ1tdXG59XG5leHBvcnQgZnVuY3Rpb24gUkVQTEhpc3RvcnkocHJvcHMgOiBSRVBMSGlzdG9yeVByb3BzKSB7XG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZXBsLWhpc3RvcnlcIj5cbiAgICAgICAgICAgIHsvKiBUaGlzIGlzIHdoZXJlIGNvbW1hbmQgaGlzdG9yeSB3aWxsIGdvICovfVxuICAgICAgICAgICAgey8qIFRPRE86IFRvIGdvIHRocm91Z2ggYWxsIHRoZSBwdXNoZWQgY29tbWFuZHMuLi4gdHJ5IHRoZSAubWFwKCkgZnVuY3Rpb24hICovfVxuICAgICAgICAgICAgey8qIENIQU5HRUQgKi99XG4gICAgICAgICAgICB7cHJvcHMuaGlzdG9yeS5tYXAoKGNvbW1hbmQsIGluZGV4KSA9PiA8cD57Y29tbWFuZH08L3A+KX1cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn0iXSwiZmlsZSI6Ii9Vc2Vycy9taWNoYWVsc3VuL2NzMzIvbW9jay1nZWFydXAvbW9jay9zcmMvY29tcG9uZW50cy9SRVBMSGlzdG9yeS50c3gifQ==