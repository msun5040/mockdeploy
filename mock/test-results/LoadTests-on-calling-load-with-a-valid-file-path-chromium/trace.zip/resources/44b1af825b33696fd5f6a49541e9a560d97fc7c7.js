"use client";
import {
  Button_default
} from "/node_modules/.vite/deps/chunk-ARGI3ARW.js?v=8e8a8cac";
import "/node_modules/.vite/deps/chunk-YP6ZGVO3.js?v=8e8a8cac";
import "/node_modules/.vite/deps/chunk-2ZZPWDJ7.js?v=8e8a8cac";
import "/node_modules/.vite/deps/chunk-MYQCFY5U.js?v=8e8a8cac";
export {
  Button_default as default
};
//# sourceMappingURL=react-bootstrap_Button.js.map
